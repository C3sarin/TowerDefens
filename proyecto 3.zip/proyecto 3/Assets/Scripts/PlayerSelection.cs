using UnityEngine;

public class PlayerSelection : MonoBehaviour
{
    public Material selectedMaterial; // Material a aplicar cuando el jugador est� seleccionado
    private Material originalMaterial; // Material original del jugador
    private Renderer playerRenderer; // Referencia al componente Renderer del jugador

    void Start()
    {
        // Obtener el componente Renderer del jugador
        playerRenderer = GetComponent<Renderer>();

        // Guardar el material original del jugador
        originalMaterial = playerRenderer.material;
    }

    void OnMouseEnter()
    {
        Debug.Log("Mouse enter");
        // Cambiar al material de selecci�n cuando el cursor entra en el collider del jugador
        playerRenderer.material = selectedMaterial;
    }

    void OnMouseExit()
    {
        Debug.Log("Mouse exit");
        // Restaurar el material original cuando el cursor sale del collider del jugador
        playerRenderer.material = originalMaterial;
    }

    void OnMouseDown()
    {
        Debug.Log("Mouse down");
        // Seleccionar al jugador cuando se hace clic en �l
        transform.parent.gameObject.tag = "Selected"; // Seleccionar al jugador (gameObject padre)
    }
}
