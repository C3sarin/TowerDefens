using UnityEngine;

public class CameraController : MonoBehaviour
{
    public float moveSpeed = 5f; // Velocidad de movimiento de la c�mara
    public float rotationSpeed = 3f; // Velocidad de rotaci�n de la c�mara

    void Update()
    {
        // Movimiento de la c�mara con las teclas direccionales o WASD
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");
        Vector3 moveDirection = new Vector3(horizontalInput, 0f, verticalInput) * moveSpeed * Time.deltaTime;
        transform.Translate(moveDirection);

        // Rotaci�n de la c�mara al presionar el scroll del rat�n y mover el mouse
        if (Input.GetMouseButton(2)) // Bot�n del medio (scroll) presionado
        {
            float mouseX = Input.GetAxis("Mouse X");
            float mouseY = Input.GetAxis("Mouse Y");
            transform.Rotate(Vector3.up, mouseX * rotationSpeed);
            transform.Rotate(Vector3.right, -mouseY * rotationSpeed);
        }
    }
}
