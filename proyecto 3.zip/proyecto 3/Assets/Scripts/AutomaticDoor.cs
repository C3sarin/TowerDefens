using UnityEngine;
using System.Collections;

public class AutomaticDoor : MonoBehaviour
{
    public float activationDistance = 3f; // Distancia a la que la puerta se activar�
    public float doorSpeed = 2f; // Velocidad de apertura de la puerta
    public Transform door; // Referencia al transform de la puerta
    private bool isOpening = false; // Variable para rastrear si la puerta est� abri�ndose

    private void Update()
    {
        // Calcula la distancia entre el jugador y la puerta
        float distance = Vector3.Distance(transform.position, door.position);

        // Si el jugador est� lo suficientemente cerca y la puerta no est� abri�ndose, abre la puerta
        if (distance <= activationDistance && !isOpening)
        {
            isOpening = true;
            StartCoroutine(OpenDoor());
        }
    }

    IEnumerator OpenDoor()
    {
        // Calcula la posici�n a la que la puerta se abrir�
        Vector3 targetPosition = door.position + (door.right * 2f); // Cambia este valor para ajustar la distancia de apertura

        // Abre la puerta gradualmente
        while (Vector3.Distance(door.position, targetPosition) > 0.1f)
        {
            door.position = Vector3.MoveTowards(door.position, targetPosition, doorSpeed * Time.deltaTime);
            yield return null;
        }
    }
}
